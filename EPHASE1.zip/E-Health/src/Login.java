import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * @Parth kaushik , Hiren Jagani
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 626, 435);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(123, 104, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEhealthSystems = new JLabel("E-HEALTH SYSTEMS");
		lblEhealthSystems.setForeground(new Color(47, 79, 79));
		lblEhealthSystems.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblEhealthSystems.setBounds(230, 11, 224, 38);
		contentPane.add(lblEhealthSystems);
		
		JLabel lblUserName = new JLabel("User Name");
		lblUserName.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblUserName.setBounds(74, 125, 127, 17);
		contentPane.add(lblUserName);
		
		textField = new JTextField();
		textField.setBounds(288, 122, 166, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblPassword.setBounds(74, 187, 86, 27);
		contentPane.add(lblPassword);
		
		textField_1 = new JTextField();
		textField_1.setBounds(288, 191, 166, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewUser = new JButton("Login");
		btnNewUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
			}
		});
		btnNewUser.setBackground(new Color(0, 139, 139));
		btnNewUser.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewUser.setBounds(285, 247, 169, 23);
		contentPane.add(btnNewUser);
		
		JButton btnNewButton = new JButton("New User / Registration");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Registration Reg = new Registration();
				Reg.setVisible(true);
				
				
			}
		});
		btnNewButton.setBounds(77, 336, 506, 23);
		contentPane.add(btnNewButton);
	}
}
