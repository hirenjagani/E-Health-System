import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DBConnect {
	
	public static void main (String args[]) {
		
		DBConnect pro = new DBConnect();
	    pro.createConnection();
	}
	
	    void createConnection(){
	    	
	    	try {
	    		
	    		Class.forName("com.mysql.jdbc.Driver");
	    		Connection con = DriverManager.getConnection("jdbc:mysql://www.papademas.net:3307/510labs?autoReconnect=true&useSSL=false","db510" ,"510");
	    		 //final String USER = "db510", PASS = "510";
	    		System.out.println("Connection Successfull");
	    	}
	    	
	    	catch (ClassNotFoundException ex) {
	    		
	    		Logger.getLogger(DBConnect.class.getName()).log(Level.SEVERE,null,ex);
	    		
	    	}
	    		catch (SQLException ex) {
	    			
	    			Logger.getLogger(DBConnect.class.getName()).log(Level.SEVERE,null,ex);
	    		
	    		
	    	}
	    	
	    }
		
	
}