import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;


public class Registration extends JFrame {

	private JPanel contentPane;
	private JLabel lblItsFreeAnd;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblSsn;
	private JLabel lblNewLabel_2;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration frame = new Registration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Registration() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 647, 452);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSignUp = new JLabel("Sign Up");
		lblSignUp.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblSignUp.setBounds(275, 11, 75, 27);
		contentPane.add(lblSignUp);
		
		lblItsFreeAnd = new JLabel("Its free and alway willbe");
		lblItsFreeAnd.setBackground(Color.GRAY);
		lblItsFreeAnd.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblItsFreeAnd.setBounds(234, 35, 169, 27);
		contentPane.add(lblItsFreeAnd);
		
		lblNewLabel = new JLabel("Name");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setBounds(68, 84, 63, 14);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("DOB");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(68, 119, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		lblSsn = new JLabel("SSN");
		lblSsn.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblSsn.setBounds(68, 154, 46, 14);
		contentPane.add(lblSsn);
		
		lblNewLabel_2 = new JLabel("Gender");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_2.setBounds(68, 206, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(264, 73, 139, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(264, 152, 139, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Times New Roman", Font.BOLD, 14));
		comboBox.setBounds(265, 204, 119, 20);
		contentPane.add(comboBox);
		comboBox.addItem("");
		comboBox.addItem("Male");
		comboBox.addItem("Female");
		
		JLabel lblNewLabel_3 = new JLabel("Mobile No");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(68, 266, 75, 14);
		contentPane.add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(264, 264, 139, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton = new JButton("Sign Up");
		btnNewButton.setBackground(new Color(51, 153, 0));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(261, 314, 123, 53);
		contentPane.add(btnNewButton);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(264, 113, 139, 20);
		contentPane.add(dateChooser);
	
		
        
	}
}
