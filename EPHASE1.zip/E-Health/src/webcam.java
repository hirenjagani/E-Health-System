import javax.imageio.ImageIO;
import java.io.*;

import com.github.sarxos.webcam.Webcam;

public class webcam {

	
	public static void main (String args[]) throws IOException {
		Webcam webcam = Webcam.getDefault();
		
		webcam.open();
		ImageIO.write(webcam.getImage(),"JPG", new File("firstcapture.jpg"));
		
		
		
		
		
		
		
		
		
	}
	
	
}
