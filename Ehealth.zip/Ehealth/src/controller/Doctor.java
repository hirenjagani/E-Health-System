package controller;

public class Doctor {
	
	public static void viewpatientrecord(){
		Report rep = new Report();
		
		Appointment app = new Appointment();
		
		
		rep.getreport();
		app.existingappointment();
	}
	
	

}
