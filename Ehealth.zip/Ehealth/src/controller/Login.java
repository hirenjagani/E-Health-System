package controller;
/**
 * 
 * @author pkaushik1
 * Create data type and methods for Login Page
 */
public class Login {

String name,username,password,email,uid;
double ssn,date ,cellno;

	public static void userlogin(){
		checklogin();
		newuser();
	}
	
	
	public static void checklogin(){
		
	}
	
	public static void newuser(){
		New_User user = new New_User();
		user.getdetails();
		Diseases deis = new Diseases();
		deis.getsymptoms();
	}
}
