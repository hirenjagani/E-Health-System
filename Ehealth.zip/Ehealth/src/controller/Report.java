package controller;

public class Report {

	String name,username,password,email,uid;
	double ssn,date ,cellno;
	
	public static void storereport(){}
	
	public static void getreport(){}
	
	public static void createreport(){}
	
	
	
}
