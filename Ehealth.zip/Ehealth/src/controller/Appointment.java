package controller;

/**
 * 
 * @author pkaushik1
 * Appointment Page with different methods to perform various task.
 */
public class Appointment {
	
	int appointmentno;
	public static void newappointment(){
		Report rep = new Report();
		rep.getreport();
	}
	
	public static void existingappointment(){
		
	}
	
	public static void bookappointment(){
		
	}
}
