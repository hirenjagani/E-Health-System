package controller;

public class Drugs  {
	String drugname,symptomsname;
	public static void drugpredict(){
		Diseases des = new Diseases();
		des.getsymptoms();
		Appointment app = new Appointment();
		app.existingappointment();
	}
	
	

}
