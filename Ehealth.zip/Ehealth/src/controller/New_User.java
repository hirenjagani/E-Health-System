package controller;

/**
 * 
 * @author pkaushik1
 *  For retreiving  new user details from login portal and storing in  database.
 */
public class New_User {
	
	String name,username,password,email,uid;
	double ssn,date ,cellno;
	public static void getdetails(){}
	
	public static void storedatabase(){}
	

}
