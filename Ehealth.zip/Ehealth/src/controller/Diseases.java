package controller;

/**
 * 
 * @author pkaushik1
 *  Disease act as an interface for report and doctor.
 */
public class Diseases {
	
	public static void getsymptoms(){}
	
	

}
